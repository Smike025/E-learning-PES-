import { Link, NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function Navbar() {
  const { user, logout } = useAuth();

  const Item = ({ to, children }) => (
    <NavLink
      to={to}
      style={({ isActive }) => ({
        padding: "6px 10px",
        borderRadius: 8,
        textDecoration: "none",
        color: isActive ? "white" : "#222",
        background: isActive ? "#111" : "transparent",
      })}
    >{children}</NavLink>
  );

  return (
    <nav style={{borderBottom:"1px solid #eee",background:"#fff"}}>
      <div style={{maxWidth:1150,margin:"0 auto",padding:"10px 16px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <Link to="/" style={{fontWeight:600,textDecoration:"none",color:"#111"}}>E-learning</Link>
        {user ? (
          <div style={{display:"flex",gap:8,alignItems:"center"}}>
            <Item to="/dashboard">Dashboard</Item>
            <Item to="/courses">Cursos</Item>
            <Item to="/my-courses">Mis cursos</Item>
            <Item to="/evaluations">Evaluaciones</Item>
            <Item to="/advisor">Asistente IA</Item>
            {user.role === "admin" && <Item to="/admin">Admin</Item>}
            <button onClick={logout} style={{padding:"6px 10px",borderRadius:8,border:"1px solid #ddd",cursor:"pointer"}}>Salir</button>
          </div>
        ) : (
          <Item to="/login">Ingresar</Item>
        )}
      </div>
    </nav>
  );
}