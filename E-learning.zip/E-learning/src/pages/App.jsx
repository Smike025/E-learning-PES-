import { Outlet } from "react-router-dom";
import { AuthProvider } from "../context/AuthContext.jsx";
import Navbar from "../components/Navbar.jsx";

export default function App() {
  return (
    <AuthProvider>
      <div style={{minHeight:"100vh",display:"flex",flexDirection:"column"}}>
        <Navbar />
        <main style={{flex:1, maxWidth:1150, margin:"0 auto", padding:"24px 16px"}}>
          <Outlet />
        </main>
        <footer style={{borderTop:"1px solid #eee",padding:"12px",textAlign:"center",color:"#666"}}>
          E-learning • React (solo frontend)
        </footer>
      </div>
    </AuthProvider>
  );
}