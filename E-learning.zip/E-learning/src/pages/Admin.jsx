export default function Admin(){ return <h2>Admin — Gestión de cursos/usuarios</h2>; }
