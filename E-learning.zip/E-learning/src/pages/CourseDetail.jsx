export default function CourseDetail(){ return <h2>Detalle de curso</h2>; }
