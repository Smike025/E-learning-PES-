import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const onSubmit = (e) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    login({ name: fd.get("name"), role: fd.get("role") });
    navigate("/dashboard");
  };

  return (
    <div style={{maxWidth:420,margin:"40px auto",background:"#fff",border:"1px solid #eee",borderRadius:12,padding:20}}>
      <h1 style={{marginBottom:12}}>Ingresar</h1>
      <form onSubmit={onSubmit} style={{display:"grid",gap:10}}>
        <label>Nombre
          <input name="name" required style={{width:"100%",padding:"8px",border:"1px solid #ddd",borderRadius:8}} />
        </label>
        <label>Rol
          <select name="role" style={{width:"100%",padding:"8px",border:"1px solid #ddd",borderRadius:8}}>
            <option value="student">Alumno</option>
            <option value="teacher">Profesor</option>
            <option value="admin">Administrador</option>
          </select>
        </label>
        <button style={{padding:"10px",borderRadius:8,background:"#111",color:"#fff",cursor:"pointer"}}>Entrar</button>
      </form>
    </div>
  );
}