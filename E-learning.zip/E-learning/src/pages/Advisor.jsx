export default function Advisor(){ return <h2>Asistente IA (FAQ y recomendaciones)</h2>; }
