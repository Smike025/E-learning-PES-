export default function MyCourses(){ return <h2>Mis cursos</h2>; }
