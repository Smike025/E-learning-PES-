import { useAuth } from "../context/AuthContext.jsx";

export default function Dashboard() {
  const { user } = useAuth();

  const roles = {
    student: "Alumno",
    teacher: "Profesor",
    admin: "Administrador",
  };

  return (
    <h2>
      Dashboard — Hola {user?.name} ({roles[user?.role]})
    </h2>
  );
}
