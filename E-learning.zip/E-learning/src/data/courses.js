export const COURSES = [
  { id: "c1", title: "Introducción a React", category: "Frontend", teacher: "Ana López", description: "Componentes, props, estado y hooks.", lessons: [{id:"l1",title:"Qué es React"},{id:"l2",title:"JSX y componentes"}] },
  { id: "c2", title: "Fundamentos de UX", category: "Diseño", teacher: "Carlos Pérez", description: "Usabilidad y diseño centrado en el usuario.", lessons: [{id:"l1",title:"Heurísticas de Nielsen"},{id:"l2",title:"Arquitectura de información"}] },
];
