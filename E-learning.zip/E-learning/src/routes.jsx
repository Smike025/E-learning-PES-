import { createBrowserRouter } from "react-router-dom";
import App from "./pages/App.jsx";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Courses from "./pages/Courses.jsx";
import MyCourses from "./pages/MyCourses.jsx";
import CourseDetail from "./pages/CourseDetail.jsx";
import Evaluations from "./pages/Evaluations.jsx";
import Admin from "./pages/Admin.jsx";
import Advisor from "./pages/Advisor.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      { index: true, element: <Login /> },
      { path: "login", element: <Login /> },
      { path: "dashboard", element: (
          <ProtectedRoute><Dashboard /></ProtectedRoute>
        ) },
      { path: "courses", element: (
          <ProtectedRoute><Courses /></ProtectedRoute>
        ) },
      { path: "my-courses", element: (
          <ProtectedRoute><MyCourses /></ProtectedRoute>
        ) },
      { path: "course/:id", element: (
          <ProtectedRoute><CourseDetail /></ProtectedRoute>
        ) },
      { path: "evaluations", element: (
          <ProtectedRoute><Evaluations /></ProtectedRoute>
        ) },
      { path: "advisor", element: (
          <ProtectedRoute><Advisor /></ProtectedRoute>
        ) },
      { path: "admin", element: (
          <ProtectedRoute roles={["admin"]}><Admin /></ProtectedRoute>
        ) },
    ],
  },
]);